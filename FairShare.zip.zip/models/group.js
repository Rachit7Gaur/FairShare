const mongoose = require("mongoose");

const groupSchema = new mongoose.Schema({
  name: { 
    type: String, 
    required: true 
  },
  owner: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "User", 
    required: true 
  },
  members: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "User" 
  }],
  expenses: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: "Expense"   
  }]
}, { timestamps: true });

module.exports = mongoose.model('Group', groupSchema);